var config = {};

config.dynamodb = {};
config.sqs = {};
config.twitter = {};

config.twitter.consumerKey = 'sjXP9IKOPpq4lzvLtGvSy6a3R';
config.twitter.consumerSecret = 'UeHHDyAke0ZympTeNU6ysZOERPeXvbQbGIaU0EPDN8lVNVkJP7';
config.twitter.accessTokenKey = '3949975300-keFgncsWq5qkDgl8Dj5Q2HhB07Qw72S19LnF3dn';
config.twitter.accessTokenSecret = 'tbP35dyp5m2mLp1VPCrdOALPhivTxxFA7ZhTtPShgOhjh';
config.dynamodb.accessKeyId = 'AKIAJSRJTPIENWFUVFYA';
config.dynamodb.secretAccessKey = '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';
config.dynamodb.region = 'us-west-2';
config.sqs.queueurl = 'https://sqs.us-west-2.amazonaws.com/545137376042/tweet';

module.exports = config;