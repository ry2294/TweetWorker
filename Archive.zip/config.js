var config = {};

config.dynamodb = {};
config.sqs = {};

config.dynamodb.accessKeyId = 'AKIAIVIRGE7VAIAVZK6A';
config.dynamodb.secretAccessKey = '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';
config.dynamodb.region = 'us-west-2';
config.sqs.queueurl = 'https://sqs.us-west-2.amazonaws.com/545137376042/tweet';

module.exports = config;