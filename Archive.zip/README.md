# TweetWorker
Worker node app to process SQS queue message
